package vending;

import java.util.List;

public interface VendingMachine {
	public long selectItemAndGetPrice(Item item);

	void insertCoin(Coin coin);

	Bucket<Item, List<Coin>> collectItemAndChange();

	List<Coin> refund();

	void reset();
}
